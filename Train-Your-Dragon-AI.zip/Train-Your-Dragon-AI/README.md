# Train Your Dragon AI ;)

A personal design project about learning how to train an AI assistant to work *with* you, instead of just answering you.

## The Problem

Most people use AI in a generic way.  
The AI has no durable understanding of how *you* think, what you value, or how you want to work.  
Every conversation starts from almost zero.

## The Approach

This project records an iterative method for training an AI collaborator:

- Build small, durable systems (skills + memory) instead of relying on chat history
- Refine through real use, not big upfront design
- Keep ownership with the human
- Only keep what actually gets used
- Review and improve when something breaks, after time passes, or when the model improves

## What This Is Not

- Not a product
- Not a prompt pack
- Not “how to use ChatGPT better”
- Not trained on a generic user

This is one person’s working method for turning a general AI into a longer-term thinking and building partner.

## How to Use This

1. Read the principles in `design-notes/principles.md`
2. Look at the memory starter example to see how durable preferences are stored
3. Examine the public skills for patterns you can adapt
4. Start small: pick one recurring friction in your own AI use and turn it into a simple skill or memory entry
5. Review and discard anything that doesn’t get used

The goal is not to copy this system. The goal is to train your own.

## Structure

- `skills/` — Reusable skills that encode working methods
- `design-notes/` — Principles and design decisions

## Core Principles

1. Durable systems over memory alone  
2. Iteration over perfect specification  
3. Human ownership  
4. Usable progress over premature perfection  
5. Review on roadblock, after ~6 months, or when the model improves  

## Status

Early and actively used.

## License

MIT License — use, copy, and adapt freely. Attribution appreciated but not required.
